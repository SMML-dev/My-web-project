CREATE DATABASE Facebook_backend;

USE Facebook_backend;

-- Create Users Table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL
);

-- Create Posts Table
CREATE TABLE posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Sample Data for Users
INSERT INTO users (username, password) VALUES
('john_doe', 'hashed_password_here'),
('jane_smith', 'hashed_password_here');

-- Sample Data for Posts
INSERT INTO posts (user_id, title, content) VALUES
(1, 'My First Post', 'This is the content of the first post!'),
(2, 'Hello World', 'Welcome to my blog!');

SHOW TABLES;
SELECT * FROM users;
SELECT * FROM posts;