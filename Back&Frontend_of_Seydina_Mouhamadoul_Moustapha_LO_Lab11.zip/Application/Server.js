const express = require('express');
const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const app = express();
const port = 3001;

// Middleware to parse JSON bodies
app.use(express.json());

const JWT_SECRET = "MySecret";

// MySQL Connection Pool
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'MhdRassul10',
  database: 'facebook_backend',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

async function testConnection() {
  try {
    const connection = await pool.getConnection();
    console.log('Connected to MySQL database!');
    connection.release();
  } catch (err) {
    console.error('Error connecting to MySQL:', err);
  }
}


// Middleware for JWT Authentication
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (token == null) return res.sendStatus(401);

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

// Register Endpoint
app.post('/register', async (req, res) => {
    try {
      const { username, password } = req.body;
      const hashedPassword = await bcrypt.hash(password, 10);
 
      const [rows] = await pool.execute(
        'INSERT INTO users (username, password) VALUES (?, ?)',
        [username, hashedPassword]
      );
 
      res.status(201).json({ message: 'User registered successfully' });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
 
 
// Login Endpoint
app.post('/login', async (req, res) => {
    try {
      const { username, password } = req.body;
 
      const [rows] = await pool.execute(
        'SELECT * FROM users WHERE username = ?',
        [username]
      );
 
      if (rows.length === 0) {
        return res.status(401).json({ message: 'User Not Found' });
      }
 
      const user = rows[0];
      const passwordMatch = await bcrypt.compare(password, user.password);
 
      if (!passwordMatch) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }
 
      const token = jwt.sign({ userId: user.id, username: user.username }, JWT_SECRET, {
        expiresIn: '1h',
      });
 
      res.json({ token });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

 
// Get User by ID (Protected Endpoint)
app.get('/users/:id', authenticateToken, async (req, res) => {
    try {
      const userId = req.params.id;
      const [rows] = await pool.execute('SELECT id, username FROM users WHERE id = ?', [userId]);
      if (rows.length === 0) {
        return res.status(404).json({ message: 'User not found' });
      }
      res.json(rows[0]);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
 
  // Get Posts (Query Parameters)
  app.get('/posts', async (req, res) => {
    try {
      const [rows] = await pool.execute('SELECT * FROM posts');
      res.json(rows);
    } catch (error) {
      console.error('Error in /posts route:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
 

testConnection();

app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`);
});